from pathlib import Path
import json, shutil, zipfile
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager, colors, patches
from matplotlib.lines import Line2D

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'work/source/csv'
OUT = ROOT / 'outputs'
OUT.mkdir(exist_ok=True)
for f in ['C:/Windows/Fonts/times.ttf','C:/Windows/Fonts/timesbd.ttf','C:/Windows/Fonts/simsun.ttc']:
    font_manager.fontManager.addfont(f)
plt.rcParams.update({
    'font.family': ['Times New Roman', 'SimSun'],
    'font.size': 8, 'axes.unicode_minus': False,
    'axes.linewidth': .55, 'axes.labelsize': 9,
    'xtick.labelsize': 8, 'ytick.labelsize': 8,
    'pdf.fonttype': 42, 'ps.fonttype': 42,
    'svg.fonttype': 'none', 'savefig.facecolor': 'white',
})
CFG = ['N_H0','N_H1','C_H0','C_H1','G_H0','G_H1','NC_H0','NC_H1','NG_H0','NG_H1','CG_H0','CG_H1','NCG_H0','NCG_H1']
MOD = [f'M{i}' for i in range(1,14)]
PRI = [f'P{i}' for i in range(1,11)]
T = pd.read_csv(SRC/'02_TVD_matrix_pp.csv',index_col=0).loc[CFG,MOD]
D = pd.read_csv(SRC/'06_signed_long_pp.csv')
assert T.shape == (14,13) and len(D)==1820
assert not D.duplicated(['model_id','configuration','priority']).any()
assert not D.isna().any().any()
assert np.allclose(D.prediction_pct-D.reference_pct,D.signed_diff_pp,atol=1e-10)
G = D.groupby(['configuration','model_id'],sort=False)
assert G.signed_diff_pp.sum().abs().max()<1e-10
rec = G.signed_diff_pp.apply(lambda v: .5*np.abs(v).sum()).unstack().loc[CFG,MOD]
assert np.allclose(rec,T,rtol=0,atol=1e-10)
assert T.values.min()>=0 and T.values.max()<=85
assert D.groupby(['configuration','priority']).size().eq(13).all()
TEAL = '#007563'
GRAY = '#7A8792'
DARK = '#152E42'

def save(fig, stem):
    for ext in ['pdf','svg','png']:
        fig.savefig(OUT/f'{stem}.{ext}', dpi=600)
    fig.savefig(ROOT/f'work/{stem}_preview.png',dpi=160)
    plt.close(fig)

# Figure 1: retain the exact matrix, linear scale, source order and columnwise minima.
fig=plt.figure(figsize=(7.35,5.6))
ax=fig.add_axes([.123,.155,.771,.708])
cmap=plt.get_cmap('YlOrRd')
norm=colors.Normalize(0,85)
im=ax.imshow(T.values,cmap=cmap,norm=norm,aspect='auto',interpolation='none')
ax.set_xticks(range(13),MOD)
ax.set_yticks(range(14),CFG)
ax.tick_params(length=0,pad=5)
ax.set_xlabel('工业场景',labelpad=7)
ax.set_ylabel('融合配置',labelpad=9)
ax.set_xticks(np.arange(-.5,13,1),minor=True)
ax.set_yticks(np.arange(-.5,14,1),minor=True)
ax.grid(which='minor',color='white',linewidth=.35,alpha=.5)
ax.tick_params(which='minor',length=0)
for y in np.arange(1.5,13,2): ax.axhline(y,color='white',lw=1.6)
for s in ax.spines.values(): s.set_color('#B7C3CD');s.set_linewidth(.5)
for j,m in enumerate(MOD):
    best=np.flatnonzero(np.isclose(T[m],T[m].min(),rtol=0,atol=1e-10))
    for i in range(14):
        v=T.iloc[i,j]
        rgba=cmap(norm(v))
        # WCAG relative luminance determines black/white annotation contrast.
        rgb=np.array(rgba[:3]); linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4)
        lum=np.dot(linear,[.2126,.7152,.0722])
        ink='white' if lum<.179 else '#142A39'
        ax.text(j,i,f'{v:.2f}',ha='center',va='center',fontsize=7.6,color=ink,
                fontweight='bold' if i in best else 'normal')
    for i in best:
        ax.add_patch(patches.Rectangle((j-.46,i-.44),.92,.88,fill=False,ec=TEAL,lw=1.45,zorder=5))
cax=fig.add_axes([.919,.155,.017,.708])
cb=fig.colorbar(im,cax=cax,ticks=[0,20,40,60,85])
cb.outline.set_linewidth(.45);cb.outline.set_edgecolor('#A6B4BE')
cb.ax.tick_params(length=2.5,width=.45,pad=3)
cb.set_label('总变差距离（百分点）',labelpad=7)
fig.text(.123,.938,'不同融合配置下的策略分布距离',fontsize=12,color=DARK)
fig.text(.123,.895,'颜色越浅，分布越接近参考',fontsize=8,color='#475965')
fig.patches.append(patches.Rectangle((.636,.889),.019,.016,transform=fig.transFigure,fill=False,ec=TEAL,lw=1.2))
fig.text(.666,.891,'同一场景中的最小距离',fontsize=8,color='#475965')
fig.text(.123,.043,'每两行依次为关闭、启用装配上下文的配对配置；所有场景共用线性色标。',fontsize=7.7,color='#475965')
save(fig,'图1_逐模型策略分布距离热力图')

# Figure 2: all seven H1 configurations, all 13 scenes.
# Outer track = all 910 H1 values; inner = repeated magnification of 260 values.
SELECTED=['N_H1','C_H1','G_H1','NC_H1','NG_H1','CG_H1','NCG_H1']
COL={'N_H1':'#384B6B','C_H1':'#D08A37','G_H1':'#8D6CAD','NC_H1':'#87949D','NG_H1':'#2878B5','CG_H1':'#78904E','NCG_H1':'#D94E4E'}
STYLE={'N_H1':(0,(5,2)), 'C_H1':'-.', 'G_H1':(0,(3,1.5)), 'NC_H1':(0,(2,2)), 'NG_H1':'-', 'CG_H1':':', 'NCG_H1':'-'}
ZOOM=['NG_H1','NCG_H1']
fig=plt.figure(figsize=(10.6,12.0))
ax=fig.add_axes([.035,.165,.93,.8215],projection='polar')
ax.set_theta_zero_location('N');ax.set_theta_direction(-1)
ax.set_ylim(0,400);ax.set_xticks([]);ax.set_yticks([])
ax.grid(False);ax.spines['polar'].set_visible(False)
sector=326/13;circle=np.linspace(0,2*np.pi,1600)
for j,m in enumerate(MOD):
    a0=17+j*sector;a1=a0+sector-1.8
    theta=np.linspace(np.deg2rad(a0),np.deg2rad(a1),100)
    shade='#F1F4F7' if j%2==0 else '#FFFFFF'
    for lo,hi in [(60,160),(195,345)]:ax.fill_between(theta,lo,hi,color=shade,zorder=0)
    ax.fill_between(theta,368,390,color='#E6EDF3' if j%2==0 else '#F0F3F6',zorder=1)
    mid=(a0+a1)/2;rot=90-mid
    if rot < -90:rot+=180
    ax.text(np.deg2rad(mid),379,m,ha='center',va='center',rotation=rot,
            rotation_mode='anchor',fontsize=11,fontweight='bold',color=DARK,zorder=6)

# Same data, two explicit linear scales. No nonlinear transform or clipped data.
for base,scale,vs in [(260,1,[-60,-40,-20,0,20,40,60,80]),(110,6,[-8,-4,0,4,8])]:
    for v in vs:
        ax.plot(circle,np.full_like(circle,base+scale*v),
                color='#465A69' if v==0 else '#CAD4DD',
                lw=1.0 if v==0 else .5,ls='-' if v==0 else (0,(2,3)),zorder=1)

records=[]
for j,m in enumerate(MOD):
    a0=17+j*sector;a1=a0+sector-1.8
    theta=np.linspace(np.deg2rad(a0+.8),np.deg2rad(a1-.8),10)
    for k,p in enumerate(PRI):
        deg=np.rad2deg(theta[k]);rot=90-deg
        if rot < -90:rot+=180
        ax.text(theta[k],356.5,p,ha='center',va='center',rotation=rot,
                rotation_mode='anchor',fontsize=7.0,color='#536575',zorder=6)
    for c in SELECTED:
        values=D[(D.model_id==m)&(D.configuration==c)].set_index('priority').loc[PRI,'signed_diff_pp'].to_numpy()
        assert np.all((-65<=values)&(values<=85))
        ax.plot(theta,260+values,color=COL[c],lw=1.1 if c in ZOOM else .9,
                ls=STYLE[c],alpha=.96 if c in ZOOM else .88,
                marker='o' if c in ZOOM else None,ms=1.4,mew=0,zorder=3+SELECTED.index(c))
        if c in ZOOM:
            assert np.max(np.abs(values))<8
            ax.plot(theta,110+6*values,color=COL[c],lw=1.15,alpha=.97,
                    marker='o',ms=1.75,mew=0,zorder=4+SELECTED.index(c))
        for p,v in zip(PRI,values):records.append({'model_id':m,'configuration':c,'priority':p,'signed_diff_pp':v})

# North opening: separate and legible rulers explain both radial tracks.
gap=np.linspace(np.deg2rad(-15.7),np.deg2rad(15.7),100)
ax.fill_between(gap,45,397,color='white',zorder=7)
for base,scale,vs,ends,label,lr in [
        (260,1,[-60,-40,-20,0,20,40,60,80],(195,343),'外环：全范围',355),
        (110,6,[-8,-4,0,4,8],(59,161),'内环：6倍放大',181)]:
    ax.plot([0,0],list(ends),color='#AAB8C3',lw=.7,zorder=8)
    for v in vs:
        rr=base+scale*v
        ax.plot([-.012,.012],[rr,rr],color='#536575',lw=.65,zorder=8)
        ax.annotate(f'{v:+d}' if v else '0',xy=(0,rr),xytext=(6,0),textcoords='offset points',
                    ha='left',va='center',fontsize=8.2,color=DARK,zorder=9,
                    bbox=dict(facecolor='white',edgecolor='none',pad=.3))
    ax.text(0,lr,label,ha='center',va='center',fontsize=8.6,color=DARK,zorder=9)
ax.fill_between(circle,0,44,color='white',zorder=10)
ax.text(0,0,'偏差\n单位：百分点',ha='center',va='center',fontsize=8.2,
        linespacing=1.6,color='#415360',zorder=11)

fig.text(.5,.980,'七种融合配置的策略档位偏差',ha='center',fontsize=16,color=DARK)
fig.text(.5,.956,'外环对比全部H1配置，内环放大NG_H1与NCG_H1；十三个场景全部保留',ha='center',fontsize=9.2,color='#536575')
handles=[Line2D([],[],color=COL[c],lw=1.7,ls=STYLE[c],label=c) for c in SELECTED]
fig.legend(handles=handles,ncol=7,loc='upper center',bbox_to_anchor=(.5,.145),
           frameon=False,fontsize=9,handlelength=2.5,columnspacing=1.25)
fig.text(.5,.105,'深灰基准环＝零偏差；曲线在环外表示偏高，在环内表示偏低。',ha='center',fontsize=9.2,color='#415360')
fig.text(.5,.078,'内环仅重复放大NG_H1、NCG_H1，量程为−8至＋8个百分点；两环须分别读取刻度。',ha='center',fontsize=8.6,color='#536575')
fig.text(.5,.052,'七种配置均启用装配上下文；每个场景按P1—P10排列，场景边界处曲线断开。',ha='center',fontsize=8.5,color='#536575')
save(fig,'图2_七种H1配置偏差环形图_含局部放大')
R=pd.DataFrame(records)
assert len(R)==910 and not R.duplicated(['model_id','configuration','priority']).any()
R.to_csv(OUT/'图2_七种H1配置对应数据.csv',index=False,encoding='utf-8-sig',float_format='%.12g')
validation={'source_signed_values':len(D),'selected_configurations':SELECTED,'unique_plotted_values':len(R),
            'outer_values':910,'inner_repeated_values':260,'scenes':13,
            'outer_mapping':'r=260+delta; scale [-65,+85] percentage points',
            'inner_mapping':'r=110+6*delta; scale [-8,+8] percentage points; NG_H1 and NCG_H1 only',
            'point_selection':'all scenes and all priorities; fixed configurations; no averaging or best-per-scene selection',
            'max_TVD_recomputation_error':float(np.abs(rec-T).values.max()),
            'font_chinese':'SimSun','font_latin_digits':'Times New Roman'}
(ROOT/'work/validation_seven_H1.json').write_text(json.dumps(validation,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(validation,ensure_ascii=False,indent=2))
